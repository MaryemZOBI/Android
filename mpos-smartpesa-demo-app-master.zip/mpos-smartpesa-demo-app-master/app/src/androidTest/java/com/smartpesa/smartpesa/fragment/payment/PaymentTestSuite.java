package com.smartpesa.smartpesa.fragment.payment;

public class PaymentTestSuite {
}
