package com.smartpesa.smartpesa.util;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({MoneyUtilTest.class, SmallCalculatorTest.class, DateUtilTest.class})
public class UtilTestSuite {
}
