package com.smartpesa.smartpesa.fragment.dialog;

import smartpesa.sdk.devices.SpTerminal;

public class TerminalDialogFragment extends BluetoothDialogFragment<SpTerminal> {
}
