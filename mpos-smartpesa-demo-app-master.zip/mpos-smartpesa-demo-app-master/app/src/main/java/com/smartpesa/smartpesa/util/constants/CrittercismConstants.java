package com.smartpesa.smartpesa.util.constants;

public class CrittercismConstants {
    public static final String KEY_METADATA_OPERATOR_ID = "operatorID";
    public static final String KEY_METADATA_MERCHANT_ID = "merchantID";
    public static final String KEY_METADATA_EMAIL_ID = "emailID";
}
