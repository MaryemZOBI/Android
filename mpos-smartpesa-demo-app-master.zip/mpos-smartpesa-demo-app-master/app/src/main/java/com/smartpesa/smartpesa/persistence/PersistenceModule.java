package com.smartpesa.smartpesa.persistence;

import dagger.Module;

@Module
public class PersistenceModule {

}
